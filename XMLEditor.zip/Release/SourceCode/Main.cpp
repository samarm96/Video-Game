/*-----------------------------------
XML Editor
Author: Michael Greer
Version 1.1
-------------------------------------

Converts .graphml files to .xml and can read contents of .graphml files.
*/

#include <iostream>
#include <string.h>
#include <cstddef>
#include "pugixml.hpp"


void printAttr(pugi::xml_node node) { //print function for reading .xml files
	for (pugi::xml_attribute attr = node.first_attribute(); attr; attr = attr.next_attribute())
	{
		std::cout << " " << attr.name() << "=" << attr.value() << std::endl;
	}

}

void cycleNodes(pugi::xml_node node) { //print function for reading .xml files
	for (node.first_child(); node; node = node.next_sibling())
	{
		std::cout << "node:" << node.name() << std::endl;
		printAttr(node);
		if (!node.text().empty()) {
			std::cout << "text: " << node.text().get() << std::endl;
		}
		cycleNodes(node.first_child());
		std::cout << std::endl;
	}
}

void graphmlToXml(std::string input, std::string output) { //function for creating .xml from .graphml

	const char* inputFile = input.c_str();
	const char* outputFile = output.c_str();

	pugi::xml_document gdoc;
	pugi::xml_parse_result result = gdoc.load_file(inputFile);
	std::string rslt = result.description();

	std::cout << "Load result: " << rslt << std::endl;



	pugi::xml_node node = gdoc.first_child();

	pugi::xml_document xdoc;
	pugi::xml_node xnode = xdoc.append_child("XNode");
	pugi::xml_node descr = xnode.append_child("description");
	descr.append_child(pugi::node_pcdata).set_value("Data extracted from .graphml file created in yEd graph editor");
	pugi::xml_node param = xnode.insert_child_before("param", descr);
	param.append_attribute("name") = "Graphml to XML";
	param.append_attribute("version") = "Version 1.1";
	param.append_attribute("author") = "Michael Greer";


	node = node.child("graph").first_child();
	pugi::xml_node node1;
	for (node.first_child(); node; node = node.next_sibling()) {
		std::cout << node.name() << std::endl;
		if (strcmp(node.name(), "node") == 0) {
			pugi::xml_node newnode = xnode.append_child("node");
			newnode.append_attribute(node.first_attribute().name()) = node.first_attribute().value();
			
			std::cout << node.first_attribute().name() << ": " << node.first_attribute().value() << std::endl;
			node1 = node.first_child();
			//std::cout << node1.name() << std::endl; 
			
			pugi::xml_node newchild = newnode.append_child("metadata	");
			std::cout << node1.first_attribute().name() << ": " << node1.first_attribute().value() << std::endl;
			
			if (!node1.text().empty()) {
				newchild.append_child(pugi::node_pcdata).set_value(node1.text().get());
				std::cout << "text: " << node1.text().get() << std::endl;
			}
			node1 = node.first_child().next_sibling().first_child();
			std::cout << node1.name() << ": " << node1.first_attribute().value() << std::endl;

			newchild = newnode.append_child("textdata");

			if (!node1.child("y:NodeLabel").text().empty()) {
				newchild.append_child(pugi::node_pcdata).set_value(node1.child("y:NodeLabel").text().get());
				std::cout << "text: " << node1.child("y:NodeLabel").text().get() << std::endl;
			}
		}
		else if (strcmp(node.name(), "edge") == 0) {
			printAttr(node);

			pugi::xml_node newedge = xnode.append_child("edge");

			for (pugi::xml_attribute attr = node.first_attribute(); attr; attr = attr.next_attribute())
			{
				newedge.append_attribute(attr.name()) = attr.value();
			}
		}
	}
	std::cout << "Saving result: " << xdoc.save_file(outputFile) << std::endl;
}

int main()
{
	int breakcode = 1;
	/*std::string input = "Test_02.graphml";
	std::string output = "Test_02.xml";*/
	std::string input;
	std::string output;
	std::string ext;
	pugi::xml_document testDoc;
	pugi::xml_parse_result result;
	pugi::xml_node node;
	int choice;
	std::string ch;

	std::cout << "XML Editor - Michael Greer - Version 1.1\n\n\n";

	while (breakcode != 0) {
		input = "";
		std::cout << "Input *.graphml file to be extracted from: ";
		std::getline(std::cin, input);
		if (input.find_last_of(".") != std::string::npos) {
			ext = input.substr(input.find_last_of("."));
		}
		else {
			std::cout << "Invalid Input.\n";
			continue;
		}
		if (ext != ".graphml") {
			std::cout << "That is an invalid file type. Please input a *.graphml filename.\n";
			continue;
		}
		result = testDoc.load_file(input.c_str());
		if (result.description() != "No error") {
			std::cout << "Error loading file.\nError type: " << result.description() << std::endl;
			if (result.description() == "File was not found") {
				std::cout << "It is possible the file in question is not in the correct directory.\nPlace *.graphml file into the directory containing the XMLEditor.exe file.\n";
			}
			std::cout << "\nType anything to try again or 0 to exit: ";
			std::getline(std::cin, ch);
			if (ch == "0") {
				return 1;
			}
			else { continue; }
		}
		breakcode = 0;
	}
	breakcode = 1;
	while (breakcode != 0) {
		std::cout << "Choose how to proceed:\n" << "1) Run .grapml to .xml\n" << "2) Print contents of input file\n" << "3) Exit Program\n";
		std::cin >> choice;
		switch (choice) {
		case 1: 
			while (1) {
				std::cout << "Input *.xml file to be outputted to: ";
				std::cin >> output;
				if (output.find_last_of(".") != std::string::npos) {
					ext = output.substr(output.find_last_of("."));
				}
				else {
					std::cout << "Invalid Input.\n";
					continue;
				}
				if (ext != ".xml") {
					std::cout << "That is an invalid file type. Please input a *.xml filename.\n";
					continue;
				}
				else { break; }
			}
			graphmlToXml(input, output);
			breakcode = 0;
			break;
		case 2:
			node = testDoc.first_child();
			cycleNodes(node);
			system("PAUSE");
			continue;
		case 3:
			breakcode = 0;
			break;
		}
	}
	
	system("PAUSE");
	return 0;
}

