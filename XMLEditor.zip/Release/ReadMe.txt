
*.graphml to *.xml editor - Created by Michael Greer
Version 1.1


The purpose of this program is to extract text and branch information from *.graphml files
and save them to a new *.xml file. The *.xml file can then be parsed and used for the creation
of complex dialogue trees in text based games. 

When extracting, make certain to input the correct *.graphml input file and the *.xml output file 
in the console window. Be careful not to overwrite a previously used output file name. Be sure that
the *.graphml file is located in the same directory as the XMLEditor.exe file. 

Functions have been included to output the data from the *.graphml file to the console. To use, 
choose to display contents of the *.graphml in the console window.

The *.graphml files are created in the free graph editor yEd. The visual dialogue trees can be 
created in yEd and saved in the *.graphml format.  

yEd can be downloaded here: https://www.yworks.com/downloads#yEd

The pugixml xml parsing library is used for xml manipulation. 

pugixml can be downloaded here: http://pugixml.org/

Future iterations may extract useful metadata from more complex graphs made in yEd. Future iterations
will also improve user interface. 