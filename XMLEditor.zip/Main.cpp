#include <iostream>
#include <string.h>
#include "pugixml.hpp"
const char* inputFile = "Test_02.graphml"; //Type filename of .graphml input file
const char* outputFile = "Test_02.xml"; //Type filename of output file to be created


void printAttr(pugi::xml_node node) { //print function for reading .xml files
	for (pugi::xml_attribute attr = node.first_attribute(); attr; attr = attr.next_attribute())
	{
		std::cout << " " << attr.name() << "=" << attr.value() << std::endl;
	}

}

void cycleNodes(pugi::xml_node node) { //print function for reading .xml files
	for (node.first_child(); node; node = node.next_sibling())
	{
		std::cout << "node:" << node.name() << std::endl;
		printAttr(node);
		if (!node.text().empty()) {
			std::cout << "text: " << node.text().get() << std::endl;
		}
		cycleNodes(node.first_child());
		std::cout << std::endl;
	}
}

void graphmlToXml(pugi::xml_node node) { //function for creating .xml from .graphml

	pugi::xml_document xdoc;
	pugi::xml_node xnode = xdoc.append_child("XNode");
	pugi::xml_node descr = xnode.append_child("description");
	descr.append_child(pugi::node_pcdata).set_value("Data extracted from .graphml file created in yEd graph editor");
	pugi::xml_node param = xnode.insert_child_before("param", descr);
	param.append_attribute("name") = "Graphml to XML";
	param.append_attribute("version") = "Version 1.0";
	param.append_attribute("author") = "Michael Greer";


	node = node.child("graph").first_child();
	pugi::xml_node node1;
	for (node.first_child(); node; node = node.next_sibling()) {
		std::cout << node.name() << std::endl;
		if (strcmp(node.name(), "node") == 0) {
			pugi::xml_node newnode = xnode.append_child("node");
			newnode.append_attribute(node.first_attribute().name()) = node.first_attribute().value();
			
			std::cout << node.first_attribute().name() << ": " << node.first_attribute().value() << std::endl;
			node1 = node.first_child();
			//std::cout << node1.name() << std::endl; 
			
			pugi::xml_node newchild = newnode.append_child("metadata	");
			std::cout << node1.first_attribute().name() << ": " << node1.first_attribute().value() << std::endl;
			
			if (!node1.text().empty()) {
				newchild.append_child(pugi::node_pcdata).set_value(node1.text().get());
				std::cout << "text: " << node1.text().get() << std::endl;
			}
			node1 = node.first_child().next_sibling().first_child();
			std::cout << node1.name() << ": " << node1.first_attribute().value() << std::endl;

			newchild = newnode.append_child("textdata");

			if (!node1.child("y:NodeLabel").text().empty()) {
				newchild.append_child(pugi::node_pcdata).set_value(node1.child("y:NodeLabel").text().get());
				std::cout << "text: " << node1.child("y:NodeLabel").text().get() << std::endl;
			}
		}
		else if (strcmp(node.name(), "edge") == 0) {
			printAttr(node);

			pugi::xml_node newedge = xnode.append_child("edge");

			for (pugi::xml_attribute attr = node.first_attribute(); attr; attr = attr.next_attribute())
			{
				newedge.append_attribute(attr.name()) = attr.value();
			}
		}
	}
	std::cout << "Saving result: " << xdoc.save_file(outputFile) << std::endl;
}

int main()
{
	/*std::string rslt = "";
	pugi::xml_document gdoc;
	pugi::xml_parse_result result;
	while (rslt != "No Error") {
		std::cout << "Input .graphml file to be extracted from: ";
		std::cin >> inputFile;
		std::cout << "Input .xml file to be outputted to: ";
		std::cin >> outputFile;
		
		result = gdoc.load_file(inputFile);
		rslt = result.description(); 
		
		std::cout << "Load result: " << rslt << std::endl;
		if (rslt == "No Error") { break; }
	}*/

	pugi::xml_document gdoc; 
	pugi::xml_parse_result result = gdoc.load_file(inputFile);
	std::string rslt = result.description();

	std::cout << "Load result: " << rslt << std::endl;



	pugi::xml_node node = gdoc.first_child();

	graphmlToXml(node);

	//cycleNodes(node);
	
	system("PAUSE");
	return 0;
}

