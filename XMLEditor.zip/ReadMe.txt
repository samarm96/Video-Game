
.graphml to .xml editor - Created by Michael Greer
Version 1.0


The purpose of this program is to extract text and branch information from .graphml files
and save them to a new .xml file. The .xml file can then be parsed and used for the creation
of complex dialogue trees in text based games. 

When extracting, make certain to input the .graphml input file and the .xml output file in
the Main.cpp file. Be careful not to overwrite a previously used output file name. 

Functions have been included to output the data from the .graphml file to the console. To use, 
comment out the graphmlToXml() function and uncomment the cycleNodes() function.

The .graphml files are created in the free graph editor yEd. The visual dialogue trees can be 
created in yEd and saved in the .graphml format.  

yEd can be downloaded here: https://www.yworks.com/downloads#yEd

The pugixml xml parsing library is used for xml manipulation. 

pugixml can be downloaded here: http://pugixml.org/

Future iterations may extract useful metadata from more complex graphs made in yEd. 